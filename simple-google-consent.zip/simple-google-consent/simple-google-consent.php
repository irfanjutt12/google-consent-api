<?php
/*
Plugin Name: Simple Google Consent Popup
Description: Displays a customizable cookie banner and manages Google Consent Mode.
Version: 1.1
Author: M.irfan ul haq
*/

add_action('wp_footer', 'simple_consent_popup_code');
function simple_consent_popup_code() {
    ?>
    <style>
#cookie-consent-banner {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background: #fff;
    padding: 30px 20px; /* increased vertical padding */
    box-shadow: 0 -2px 10px rgba(0,0,0,0.15);
    z-index: 9999;
    display: none;
    font-family: sans-serif;
    border-top: 1px solid #ccc;
    text-align: center;
    min-height: 100px; /* optional: ensures minimum height */
}
#cookie-consent-banner p {
    margin: 0 0 15px;
}
#cookie-consent-banner button {
    background: #0073aa;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    cursor: pointer;
    margin: 0 5px;
}
#cookie-consent-banner button#decline-cookies {
    background: #888;
}
</style>


    <div id="cookie-consent-banner">
        <p>
        We use cookies to enhance your browsing experience, serve personalised ads or content, and analyse our traffic. <br>
        By clicking "Accept Cookies", you consent to our use of cookies. 
        <a href="/privacy-policy" target="_blank" style="color: #0073aa; text-decoration: underline;">Learn more in our Privacy Policy.</a>
        </p>
        <button id="accept-cookies">Accept Cookies</button>
        <button id="decline-cookies">Decline</button>
    </div>

    <script>
    function showConsentBanner() {
        console.log("Consent:"+ localStorage.getItem('cookie_consent_status'));
        if (!localStorage.getItem('cookie_consent_status')) {
            document.getElementById('cookie-consent-banner').style.display = 'block';
        }
    }

    function updateConsent() {
        if (typeof gtag === 'function') {
            gtag('consent', 'update', {
                'ad_storage': 'granted',
                'analytics_storage': 'granted',
                'functionality_storage': 'granted',
                'personalization_storage': 'granted',
                'security_storage': 'granted',
                'ad_user_data': 'granted',
                'ad_personalization': 'granted'
            });
            // Fire custom event for GTM or tracking
            if (typeof dataLayer !== 'undefined') {
                dataLayer.push({ event: 'cookie_consent_update' });
            }
        }
    }

    function denyConsent() {
        if (typeof gtag === 'function') {
            gtag('consent', 'default', {
                'ad_storage': 'denied',
                'analytics_storage': 'denied',
                'functionality_storage': 'denied',
                'personalization_storage': 'denied',
                'security_storage': 'denied',
                'ad_user_data': 'denied',
                'ad_personalization': 'denied'
            });
            // Fire custom event for GTM or tracking
            if (typeof dataLayer !== 'undefined') {
                dataLayer.push({ event: 'cookie_consent_update' });
            }
        }
    }

    document.getElementById('accept-cookies').addEventListener('click', function() {
        localStorage.setItem('cookie_consent_status', 'accepted');
        document.getElementById('cookie-consent-banner').style.display = 'none';
        updateConsent();
    });

    document.getElementById('decline-cookies').addEventListener('click', function() {
        localStorage.setItem('cookie_consent_status', 'declined');
        document.getElementById('cookie-consent-banner').style.display = 'none';
        denyConsent();
    });

    // Scroll trigger (optional)
    // window.addEventListener('scroll', function triggerScroll() {
    //     showConsentBanner();
    //     window.removeEventListener('scroll', triggerScroll);
    // });
    // Run on page load
    document.addEventListener('DOMContentLoaded', function () {
        if (localStorage.getItem('cookie_consent_status') === 'accepted') {
            updateConsent(); // Grant again, just to be safe (idempotent)
            console.log('accepted');
        } else if(localStorage.getItem('cookie_consent_status') === 'declined'){
          denyConsent();
          console.log('declined');
        } else {
            // Show banner if not accepted
            showConsentBanner();
        }
    });

    // Uncomment for time delay (e.g. 5 seconds)
    // setTimeout(showConsentBanner, 5000);

    // Uncomment for click trigger
    // document.body.addEventListener('click', function clickTrigger() {
    //     showConsentBanner();
    //     document.body.removeEventListener('click', clickTrigger);
    // });
    </script>
    <?php
}